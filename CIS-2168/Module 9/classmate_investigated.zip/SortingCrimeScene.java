import java.util.*;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Map;

public class SortingCrimeScene {

    // === Statistic tracker ===
    static class SortStats {
        private int comparisons = 0;
        private int exchanges   = 0;

        void cmp()    { comparisons++; }
        void exch()   { exchanges++;    }

        Map<String,Integer> toMap() {
            Map<String,Integer> m = new HashMap<>();
            m.put("comparisons", comparisons);
            m.put("exchanges",    exchanges);
            return m;
        }
    }

    static class Sort2 {
        public static <T extends Comparable<? super T>>
        Map<String,Integer> sort(T[] arr) {
            SortStats stats = new SortStats();
            for (int i = 1; i < arr.length; i++) {
                T key = arr[i];
                int j = i - 1;
                while (j >= 0) {
                    stats.cmp();
                    if (arr[j].compareTo(key) > 0) {
                        arr[j + 1] = arr[j];
                        stats.exch();
                        j--;
                    } else {
                        break;
                    }
                }
                arr[j + 1] = key;
                stats.exch();
            }
            return stats.toMap();
        }
    }

    static class Sort3 {
        public static <T extends Comparable<? super T>>
        Map<String,Integer> sort(T[] arr) {
            SortStats stats = new SortStats();
            quicksort(arr, 0, arr.length - 1, stats);
            return stats.toMap();
        }

        private static <T extends Comparable<? super T>>
        void quicksort(T[] A, int lo, int hi, SortStats stats) {
            if (lo < hi) {
                int p = partition(A, lo, hi, stats);
                quicksort(A, lo, p - 1, stats);
                quicksort(A, p + 1, hi, stats);
            }
        }

        private static <T extends Comparable<? super T>>
        int partition(T[] A, int lo, int hi, SortStats stats) {
            T pivot = A[hi];
            int i = lo;
            for (int j = lo; j < hi; j++) {
                stats.cmp();
                if (A[j].compareTo(pivot) <= 0) {
                    swap(A, i, j, stats);
                    i++;
                }
            }
            swap(A, i, hi, stats);
            return i;
        }

        private static <T> void swap(T[] A, int i, int j, SortStats stats) {
            T tmp = A[i];
            A[i] = A[j];
            A[j] = tmp;
            stats.exch();
        }
    }

    static class Sort1 {
        public static <T extends Comparable<? super T>>
        Map<String,Integer> sort(T[] arr) {
            SortStats stats = new SortStats();
            final int RUN = 32;
            // 1) insertion sort on small runs
            for (int i = 0; i < arr.length; i += RUN) {
                insertion(arr, i, Math.min(i + RUN - 1, arr.length - 1), stats);
            }
            // 2) merge runs of size RUN, 2*RUN, 4*RUN...
            for (int size = RUN; size < arr.length; size *= 2) {
                for (int lo = 0; lo < arr.length; lo += 2 * size) {
                    int mid = lo + size - 1;
                    int hi  = Math.min(lo + 2 * size - 1, arr.length - 1);
                    if (mid < hi) {
                        merge(arr, lo, mid, hi, stats);
                    }
                }
            }
            return stats.toMap();
        }

        private static <T extends Comparable<? super T>>
        void insertion(T[] A, int lo, int hi, SortStats stats) {
            for (int i = lo + 1; i <= hi; i++) {
                T key = A[i];
                int j = i - 1;
                while (j >= lo) {
                    stats.cmp();
                    if (A[j].compareTo(key) > 0) {
                        A[j + 1] = A[j]; stats.exch(); j--;
                    } else break;
                }
                A[j + 1] = key;
                stats.exch();
            }
        }

        private static <T extends Comparable<? super T>>
        void merge(T[] A, int lo, int mid, int hi, SortStats stats) {
            int n1 = mid - lo + 1, n2 = hi - mid;
            Object[] L = new Object[n1];
            Object[] R = new Object[n2];
            for (int i = 0; i < n1; i++) L[i] = A[lo + i];
            for (int j = 0; j < n2; j++) R[j] = A[mid + 1 + j];

            int i = 0, j = 0, k = lo;
            while (i < n1 && j < n2) {
                @SuppressWarnings("unchecked") T lval = (T)L[i];
                @SuppressWarnings("unchecked") T rval = (T)R[j];
                stats.cmp();
                if (lval.compareTo(rval) <= 0) { A[k++] = lval; stats.exch(); i++; }
                else                     { A[k++] = rval; stats.exch(); j++; }
            }
            while (i < n1) { @SuppressWarnings("unchecked") T val = (T)L[i++]; A[k++] = val; stats.exch(); }
            while (j < n2) { @SuppressWarnings("unchecked") T val = (T)R[j++]; A[k++] = val; stats.exch(); }
        }
    }

    // === Test Harness & CSV Output (with timing) ===
    private static Integer[] makeArray(int n, String pat) {
        Integer[] a = new Integer[n];
        switch (pat) {
            case "sorted":  for (int i = 0; i < n; i++) a[i] = i; break;
            case "reverse": for (int i = 0; i < n; i++) a[i] = n - i; break;
            default:
                Random r = new Random(42);
                for (int i = 0; i < n; i++) a[i] = r.nextInt(n);
        }
        return a;
    }

    public static void runTests(String outputPath) throws Exception {
        int[] sizes   = {64, 128, 256, 512, 1024};
        String[] pats = {"random", "sorted", "reverse"};
        int trials = 5;
        try (FileWriter fw = new FileWriter(outputPath)) {
            fw.write("algorithm,size,pattern,time_ns,comparisons,exchanges\n");
            for (int n : sizes) {
                for (String pat : pats) {
                    Integer[] data = makeArray(n, pat);
                    for (String alg : List.of("Sort1","Sort2","Sort3")) {
                        long totalDuration = 0;
                        long totalComparisons = 0;
                        long totalExchanges = 0;
                        for (int t = 0; t < trials; t++) {
                            Integer[] copy = Arrays.copyOf(data, n);
                            long start = System.nanoTime();
                            Map<String,Integer> st;
                            switch (alg) {
                                case "Sort1": st = Sort1.sort(copy); break;
                                case "Sort2": st = Sort2.sort(copy); break;
                                default:       st = Sort3.sort(copy);
                            }
                            long duration = System.nanoTime() - start;
                            totalDuration += duration;
                            totalComparisons += st.get("comparisons");
                            totalExchanges += st.get("exchanges");
                        }
                        long avgDuration = totalDuration / trials;
                        long avgComparisons = totalComparisons / trials;
                        long avgExchanges = totalExchanges / trials;
                        fw.write(String.format(
                                "%s,%d,%s,%d,%d,%d\n",
                                alg, n, pat,
                                avgDuration,
                                avgComparisons,
                                avgExchanges
                        ));
                    }
                }
            }
        }
        System.out.println("Data written to " + outputPath);
    }

    public static void main(String[] args) throws Exception {
        runTests("sort_evidence.csv");
    }
}
